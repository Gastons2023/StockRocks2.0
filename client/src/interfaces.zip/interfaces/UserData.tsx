export interface UserData {
    id: number | null;
    username: string | null;
  }
  