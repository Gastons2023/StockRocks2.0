export interface ApiMessage {
    message: string;
  }
  